﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Btn_Rank3 : MonoBehaviour
{

    void GoToRank3()
    {

        //记录LOADING场景中需要读取的C场景名称
        Globe.loadName = "Rank3";
        //先进入B场景
        Application.LoadLevel("Loading");

    }
}
