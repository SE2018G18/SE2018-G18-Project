﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Btn_Rank2 : MonoBehaviour
{

    void GoToRank2()
    {

        //记录LOADING场景中需要读取的C场景名称
        Globe.loadName = "Rank2";
        //先进入B场景
        Application.LoadLevel("Loading");

    }
}
