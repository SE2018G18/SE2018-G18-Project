﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Btn_Rank1 : MonoBehaviour
{

    void GoToRank1()
    {

        //记录LOADING场景中需要读取的C场景名称
        Globe.loadName = "Rank1";
        //先进入B场景
        Application.LoadLevel("Loading");

    }
}
