﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RankData : MonoBehaviour {

    public static String name1;
    public static String name2;
    public static String name3;
    public static String name4;
    public static String name5;
    public static float score1;
    public static float score2;
    public static float score3;
    public static float score4;
    public static float score5;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		 
}
    void Data()
    {
        string constr = "Database=user;Data Source=sh-cdb-0sbjdp2b.sql.tencentcdb.com;User Id=root;Password=se2018-g18;port=63075"; //设置连接字符串
        MySqlConnection mycon = new MySqlConnection(constr);

        //
        mycon.Open();
        MySqlCommand mycom1 = mycon.CreateCommand();
        if (Application.loadedLevelName == "Rank1")
        {
            string s1 = "select u_name1,u_score1 from Rank order by u_score1 desc limit 0,1";
            mycom1.CommandText = s1;
            MySqlDataReader re1 = mycom1.ExecuteReader();
            if (re1.Read())
            {
                name1 = (String)re1.GetValue(0);
                score1 = (float)re1.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();

        }
        else if (Application.loadedLevelName == "Rank2")
        {
            string s1 = "select u_name1,u_score2 from Rank order by u_score2 desc limit 0,1";
            mycom1.CommandText = s1;
            MySqlDataReader re1 = mycom1.ExecuteReader();
            if (re1.Read())
            {
                name1 = (String)re1.GetValue(0);
                score1 = (float)re1.GetValue(1);
            }

            mycon.Close();
            mycon.Dispose();

        }
        else if (Application.loadedLevelName == "Rank3")
        {
            string s1 = "select u_name1,u_score3 from Rank order by u_score3 desc limit 0,1";
            mycom1.CommandText = s1;
            MySqlDataReader re1 = mycom1.ExecuteReader();
            if (re1.Read())
            {
                name1 = (String)re1.GetValue(0);
                score1 = (float)re1.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();

        }


        //
        mycon.Open();
        MySqlCommand mycom2 = mycon.CreateCommand();
        if (Application.loadedLevelName == "Rank1")
        {
            string s2 = "select u_name1,u_score1 from Rank order by u_score1 desc limit 1,1";
            mycom2.CommandText = s2;
            MySqlDataReader re2 = mycom2.ExecuteReader();
            if (re2.Read())
            {
                name2 = (String)re2.GetValue(0);
                score2 = (float)re2.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();

        }
        else if (Application.loadedLevelName == "Rank2")
        {
            string s2 = "select u_name1,u_score2 from Rank order by u_score2 desc limit 1,1";
            mycom2.CommandText = s2;
            MySqlDataReader re2 = mycom2.ExecuteReader();
            if (re2.Read())
            {
                name2 = (String)re2.GetValue(0);
                score2 = (float)re2.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();
        }
        else if (Application.loadedLevelName == "Rank3")
        {
            string s2 = "select u_name1,u_score3 from Rank order by u_score3 desc limit 1,1";
            mycom2.CommandText = s2;
            MySqlDataReader re2 = mycom2.ExecuteReader();
            if (re2.Read())
            {
                name2 = (String)re2.GetValue(0);
                score2 = (float)re2.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();

        }

        //
        mycon.Open();
        MySqlCommand mycom3 = mycon.CreateCommand();
        if (Application.loadedLevelName == "Rank1")
        {
            string s3 = "select u_name1,u_score1 from Rank order by u_score1 desc limit 2,1";
            mycom3.CommandText = s3;
            MySqlDataReader re3 = mycom3.ExecuteReader();
            if (re3.Read())
            {
                name3 = (String)re3.GetValue(0);
                score3 = (float)re3.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();

        }
        else if (Application.loadedLevelName == "Rank2")
        {
            string s3 = "select u_name1,u_score2 from Rank order by u_score2 desc limit 2,1";
            mycom3.CommandText = s3;
            MySqlDataReader re3 = mycom3.ExecuteReader();
            if (re3.Read())
            {
                name3 = (String)re3.GetValue(0);
                score3 = (float)re3.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();

        }
        else if (Application.loadedLevelName == "Rank3")
        {
            string s3 = "select u_name1,u_score3 from Rank order by u_score3 desc limit 2,1";
            mycom3.CommandText = s3;
            MySqlDataReader re3 = mycom3.ExecuteReader();
            if (re3.Read())
            {
                name3 = (String)re3.GetValue(0);
                score3 = (float)re3.GetValue(1);
            }

            mycon.Close();
            mycon.Dispose();

        }



        //
        mycon.Open();
        MySqlCommand mycom4 = mycon.CreateCommand();
        if (Application.loadedLevelName == "Rank1")
        {
            string s4 = "select u_name1,u_score1 from Rank order by u_score1 desc limit 3,1";
            mycom4.CommandText = s4;
            MySqlDataReader re4 = mycom4.ExecuteReader();
            if (re4.Read())
            {
                name4 = (String)re4.GetValue(0);
                score4 = (float)re4.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();

        }
        else if (Application.loadedLevelName == "Rank2")
        {
            string s4 = "select u_name1,u_score2 from Rank order by u_score2 desc limit 3,1";
            mycom4.CommandText = s4;
            MySqlDataReader re4 = mycom4.ExecuteReader();
            if (re4.Read())
            {
                name4 = (String)re4.GetValue(0);
                score4 = (float)re4.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();

        }
        else if (Application.loadedLevelName == "Rank3")
        {
            string s4 = "select u_name1,u_score3 from Rank order by u_score3 desc limit 3,1";
            mycom4.CommandText = s4;
            MySqlDataReader re4 = mycom4.ExecuteReader();
            if (re4.Read())
            {
                name4 = (String)re4.GetValue(0);
                score4 = (float)re4.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();
        }


        //
        mycon.Open();
        MySqlCommand mycom5 = mycon.CreateCommand();
        if (Application.loadedLevelName == "Rank1")
        {
            string s5 = "select u_name1,u_score1 from Rank order by u_score1 desc limit 4,1";
            mycom5.CommandText = s5;
            MySqlDataReader re5 = mycom5.ExecuteReader();
            if (re5.Read())
            {
                name5 = (String)re5.GetValue(0);
                score5 = (float)re5.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();
        }
        else if (Application.loadedLevelName == "Rank2")
        {
            string s5 = "select u_name1,u_score2 from Rank order by u_score2 desc limit 4,1";
            mycom5.CommandText = s5;
            MySqlDataReader re5 = mycom5.ExecuteReader();
            if (re5.Read())
            {
                name5 = (String)re5.GetValue(0);
                score5 = (float)re5.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();
        }
        else if (Application.loadedLevelName == "Rank3")
        {
            string s5 = "select u_name1,u_score3 from Rank order by u_score3 desc limit 4,1";
            mycom5.CommandText = s5;
            MySqlDataReader re5 = mycom5.ExecuteReader();
            if (re5.Read())
            {
                name5 = (String)re5.GetValue(0);
                score5 = (float)re5.GetValue(1);
            }
            mycon.Close();
            mycon.Dispose();
        }
    }
}


    

