﻿using UnityEngine;
using System.Collections;
using MySql.Data.MySqlClient;
using System;

public class RankList : MonoBehaviour
{

    public String name1;
    public String name2;
    public String name3;
    public String name4;
    public String name5;
    public float score1;
    public float score2;
    public float score3;
    public float score4;
    public float score5;
    
    // Use this for initialization
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnGUI()
    {
        GUIStyle GS = new GUIStyle();
        GS.normal.background = null;
        GS.normal.textColor = new Color(255, 0, 0);
        GS.fontSize = 40;

        string constr = "Database=user;Data Source=sh-cdb-0sbjdp2b.sql.tencentcdb.com;User Id=root;Password=se2018-g18;port=63075"; //设置连接字符串
        MySqlConnection mycon = new MySqlConnection(constr);
        mycon.Open();
        
        //
        
        MySqlCommand mycom1 = mycon.CreateCommand();
        if (Application.loadedLevelName == "Rank1")
        {
            string s1 = "select u_name1,u_score1 from Rank1 order by u_score1 desc limit 0,1";
            mycom1.CommandText = s1;
            MySqlDataReader re1 = mycom1.ExecuteReader();
            if (re1.Read())
            {
                name1 = (String)re1.GetValue(0);
                score1 = (float)re1.GetValue(1);
            }
            re1.Close();

        }
        else if (Application.loadedLevelName == "Rank2")
        {
            string s1 = "select u_name2,u_score2 from Rank2 order by u_score2 desc limit 0,1";
            mycom1.CommandText = s1;
            MySqlDataReader re1 = mycom1.ExecuteReader();
            if (re1.Read())
            {
                name1 = (String)re1.GetValue(0);
                score1 = (float)re1.GetValue(1);
            }
            re1.Close();


        }
        else if (Application.loadedLevelName == "Rank3")
        {
            string s1 = "select u_name3,u_score3 from Rank3 order by u_score3 desc limit 0,1";
            mycom1.CommandText = s1;
            MySqlDataReader re1 = mycom1.ExecuteReader();
            if (re1.Read())
            {
                name1 = (String)re1.GetValue(0);
                score1 = (float)re1.GetValue(1);
            }
            re1.Close();

        }
        GUI.Label(new Rect(750, 400, 200, 100), name1, GS);
        GUI.Label(new Rect(1050, 400, 200, 100), score1.ToString(), GS);

        //
        
        MySqlCommand mycom2 = mycon.CreateCommand();
        if (Application.loadedLevelName == "Rank1")
        {
            string s2 = "select u_name1,u_score1 from Rank1 order by u_score1 desc limit 1,1";
            mycom2.CommandText = s2;
            MySqlDataReader re2 = mycom2.ExecuteReader();
            if (re2.Read())
            {
                name2 = (String)re2.GetValue(0);
                score2 = (float)re2.GetValue(1);
            }
            re2.Close();

        }
        else if (Application.loadedLevelName == "Rank2")
        {
            string s2 = "select u_name2,u_score2 from Rank2 order by u_score2 desc limit 1,1";
            mycom2.CommandText = s2;
            MySqlDataReader re2 = mycom2.ExecuteReader();
            if (re2.Read())
            {
                name2 = (String)re2.GetValue(0);
                score2 = (float)re2.GetValue(1);
            }
            re2.Close();
        }
        else if (Application.loadedLevelName == "Rank3")
        {
            string s2 = "select u_name3,u_score3 from Rank3 order by u_score3 desc limit 1,1";
            mycom2.CommandText = s2;
            MySqlDataReader re2 = mycom2.ExecuteReader();
            if (re2.Read())
            {
                name2 = (String)re2.GetValue(0);
                score2 = (float)re2.GetValue(1);
            }

            re2.Close();
        }
        GUI.Label(new Rect(750, 450, 200, 100), name2, GS);
        GUI.Label(new Rect(1050, 450, 200, 100), score2.ToString(), GS);

        //
        
        MySqlCommand mycom3 = mycon.CreateCommand();
        if (Application.loadedLevelName == "Rank1")
        {
            string s3 = "select u_name1,u_score1 from Rank1 order by u_score1 desc limit 2,1";
            mycom3.CommandText = s3;
            MySqlDataReader re3 = mycom3.ExecuteReader();
            if (re3.Read())
            {
                name3 = (String)re3.GetValue(0);
                score3 = (float)re3.GetValue(1);
            }
            re3.Close();

        }
        else if (Application.loadedLevelName == "Rank2")
        {
            string s3 = "select u_name2,u_score2 from Rank2 order by u_score2 desc limit 2,1";
            mycom3.CommandText = s3;
            MySqlDataReader re3 = mycom3.ExecuteReader();
            if (re3.Read())
            {
                name3 = (String)re3.GetValue(0);
                score3 = (float)re3.GetValue(1);
            }
            re3.Close();

        }
        else if (Application.loadedLevelName == "Rank3")
        {
            string s3 = "select u_name3,u_score3 from Rank3 order by u_score3 desc limit 2,1";
            mycom3.CommandText = s3;
            MySqlDataReader re3 = mycom3.ExecuteReader();
            if (re3.Read())
            {
                name3 = (String)re3.GetValue(0);
                score3 = (float)re3.GetValue(1);
            }
            re3.Close();


        }
        GUI.Label(new Rect(750, 500, 200, 100), name3, GS);
        GUI.Label(new Rect(1050, 500, 200, 100), score3.ToString(), GS);


        //
        
        MySqlCommand mycom4 = mycon.CreateCommand();
        if (Application.loadedLevelName == "Rank1")
        {
            string s4 = "select u_name1,u_score1 from Rank1 order by u_score1 desc limit 3,1";
            mycom4.CommandText = s4;
            MySqlDataReader re4 = mycom4.ExecuteReader();
            if (re4.Read())
            {
                name4 = (String)re4.GetValue(0);
                score4 = (float)re4.GetValue(1);
            }
            re4.Close();

        }
        else if (Application.loadedLevelName == "Rank2")
        {
            string s4 = "select u_name2,u_score2 from Rank2 order by u_score2 desc limit 3,1";
            mycom4.CommandText = s4;
            MySqlDataReader re4 = mycom4.ExecuteReader();
            if (re4.Read())
            {
                name4 = (String)re4.GetValue(0);
                score4 = (float)re4.GetValue(1);
            }

            re4.Close();
        }
        else if (Application.loadedLevelName == "Rank3")
        {
            string s4 = "select u_name3,u_score3 from Rank3 order by u_score3 desc limit 3,1";
            mycom4.CommandText = s4;
            MySqlDataReader re4 = mycom4.ExecuteReader();
            if (re4.Read())
            {
                name4 = (String)re4.GetValue(0);
                score4 = (float)re4.GetValue(1);
            }
            re4.Close();
        }
        GUI.Label(new Rect(750, 550, 200, 100), name4, GS);
        GUI.Label(new Rect(1050, 550, 200, 100), score4.ToString(), GS);

        //
        
        MySqlCommand mycom5 = mycon.CreateCommand();
        if (Application.loadedLevelName == "Rank1")
        {
            string s5 = "select u_name1,u_score1 from Rank1 order by u_score1 desc limit 4,1";
            mycom5.CommandText = s5;
            MySqlDataReader re5 = mycom5.ExecuteReader();
            if (re5.Read())
            {
                name5 = (String)re5.GetValue(0);
                score5 = (float)re5.GetValue(1);
            }
            re5.Close();
        }
        else if (Application.loadedLevelName == "Rank2")
        {
            string s5 = "select u_name2,u_score2 from Rank2 order by u_score2 desc limit 4,1";
            mycom5.CommandText = s5;
            MySqlDataReader re5 = mycom5.ExecuteReader();
            if (re5.Read())
            {
                name5 = (String)re5.GetValue(0);
                score5 = (float)re5.GetValue(1);
            }
            re5.Close();
        }
        else if (Application.loadedLevelName == "Rank3")
        {
            string s5 = "select u_name3,u_score3 from Rank3 order by u_score3 desc limit 4,1";
            mycom5.CommandText = s5;
            MySqlDataReader re5 = mycom5.ExecuteReader();
            if (re5.Read())
            {
                name5 = (String)re5.GetValue(0);
                score5 = (float)re5.GetValue(1);
            }
            re5.Close();
        }

        GUI.Label(new Rect(750, 600, 200, 100), name5, GS);
        GUI.Label(new Rect(1050, 600, 200, 100), score5.ToString(), GS);

        //关闭连接
        mycon.Close();
        mycon.Dispose();                     //释放对象
    }
    
        
 }
