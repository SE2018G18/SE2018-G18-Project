﻿using MySql.Data.MySqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using UnityEngine;
using UnityEngine.UI;

public class Register2 : MonoBehaviour {
    
    //注册信息
    public InputField inputName;
    public InputField inputPaswd;
    public InputField inputPaswd2;



    //跳转场景名称
    public string LoadSceneName;


    //GUI 提示信息
    public Text ui_massage;
    private string stringmassage;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        ui_massage.text = stringmassage;
    }

    void OnCLick()
    {
     
        string name = inputName.text.Trim(); //取出账号
        string password = inputPaswd.text.Trim();
        string password2 = inputPaswd2.text.Trim();

        //检查是否已经存在

        /**
         * 连接数据库
         */
        string constr = "Database=user;Data Source=sh-cdb-0sbjdp2b.sql.tencentcdb.com;User Id=root;Password=se2018-g18;pooling=false;port=63075"; //设置连接字符串
        MySqlConnection mycon = new MySqlConnection(constr);                  //实例化连接对象
        mycon.Open();


        //查询新注册的用户是否存在
        MySqlCommand checkCmd = mycon.CreateCommand();       //创建SQL命令执行对象
        string s = "select u_name from user where u_name='" + name + "'";
        checkCmd.CommandText = s;
        MySqlDataAdapter check = new MySqlDataAdapter();       //实例化数据适配器
        check.SelectCommand = checkCmd;                    //让适配器执行SELECT命令
        DataSet checkData = new DataSet();                 //实例化结果数据集
        int n = check.Fill(checkData, "user");         //将结果放入数据适配器，返回元祖个数
        if (n != 0)
        {
            print(stringmassage = "提示信息：用户名存在");
            inputName.text = ""; inputPaswd.text = "";
            inputPaswd2.text = "";
        }

        //插入数据SQL
        string s1 = "insert into user(u_name,u_pass) values ('" + inputName.text + "','" + inputPaswd.text + "')";
        //编写SQL命令
        MySqlCommand mycom = new MySqlCommand(s1, mycon);          //初始化命令
        mycom.ExecuteNonQuery();             //执行语句
        
        mycon.Close();                       //关闭连接
        mycom = null;
        mycon.Dispose();                     //释放对象

        //确认密码
        if (inputPaswd2.text != inputPaswd.text)
        {
            inputPaswd2.text = "";
        }
        //用户名密码正确则跳转场景
        if (string.IsNullOrEmpty(name))
        {

            print(stringmassage = "提示信息：请输入昵称");
            return;
        }
        else if (string.IsNullOrEmpty(password) || inputPaswd.text.Length != 8)
        {

            print(stringmassage = "提示信息：请输入8位密码");
            return;
        }
        else if (string.IsNullOrEmpty(password2))
        {

            print(stringmassage = "提示信息：请输入确认密码");
            return;
        }
        else if (password != password2)
        {

            print(stringmassage = "提示信息：两次密码输入不正确");
            return;
        }
        else
        {
            print(stringmassage = "提示信息：注册成功");
            Application.LoadLevel(LoadSceneName);
        }
    }

    void returntoload()
    {

        Application.LoadLevel("load");

    }
}
