﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;//注意这个不能少  
public class Btn_Level1 : MonoBehaviour
{
    // Use this for initialization  
    

        void GoToLevel1()
        {

            //记录LOADING场景中需要读取的C场景名称
            Globe.loadName = "Level1";
            //先进入B场景
            Application.LoadLevel("Loading");

        }
    }
