using UnityEngine;
using System.Collections;
using MySql.Data.MySqlClient;


//游戏状态
public enum GameState
{
	Play,
	Pause,
	End,
}

public class Game_Manager : MonoBehaviour
{
    
    public string name;
    public GameState GS;
	public int GameLv;
	public float GameSpeed;
	public Box_Loop _BL;
	public Scroll_Mapping _SM;

	//持续变量

	public float Meter;
	public int GetMoney = 0;
    public float score;

	//GUI

	public GUIText Gold_Label;
	public GUIText Meter_Label;
	public GUITexture Black_screen;
	public GUIText result_Gold_Label;
	public GUIText result_Meter_Label;
	GUIStyle guiRectStyle;
	public Fade _fade;
	public Texture Pause_btn;
	public Texture Go_btn;
	public Texture Replay_btn;
	public Texture Main_btn;
    public GameObject result_window;
	float screenX;
	float screenY;

    

    void Start ()
	{
        
        name = Login2.uname;
        GameObject a = GameObject.Find("02_Box_Maker");
		if(a!=null)_BL = a.GetComponent<Box_Loop>();		
		GameObject b = GameObject.Find("01_Sky");
		if(b!=null)_SM = b.GetComponent<Scroll_Mapping>();
        GameSpeed = _BL.Speed;		
		SCREENSETTING ();
	}

	void Update ()
	{
		if (GS == GameState.Play) {
			METERUPDATE ();
		}

	}
	
	void SCREENSETTING ()
	{
		screenX = UnityEngine.Screen.width;
		screenY = UnityEngine.Screen.height;
		guiRectStyle = new GUIStyle ();
		guiRectStyle.border = new RectOffset (0, 0, 0, 0);
		_fade.FadeIn ();
	}
	
	void OnGUI ()
	{
        //游戏运行时的暂停按钮

        if (GS == GameState.Play)
        {

            if (GUI.Button(new Rect(20, 20, Pause_btn.width, Pause_btn.height), Pause_btn, guiRectStyle))
            {
                Black_screen.color = new Color(0, 0, 0, 0.4f);
                GS = GameState.Pause;
                Time.timeScale = 0;
            }

        }


		//进入停止状态的按钮

		if (GS == GameState.Pause) {

			if (GUI.Button (new Rect (screenX * 0.5f - Go_btn.width * 0.5f, screenY * 0.5f + Replay_btn.height * 0.5f + 10f, Go_btn.width, Go_btn.height), Go_btn, guiRectStyle)) {
				Black_screen.color = new Color (0, 0, 0, 0);
				Time.timeScale = 1;
				GS = GameState.Play;

			}

			if (GUI.Button (new Rect (screenX * 0.5f - Replay_btn.width * 0.5f, screenY * 0.5f - Replay_btn.height * 0.5f, Replay_btn.width, Replay_btn.height), Replay_btn, guiRectStyle)) {
				Time.timeScale = 1;
                Application.LoadLevel ("[PlayScene]");
			}

			if (GUI.Button (new Rect (screenX * 0.5f - Main_btn.width * 0.5f, screenY * 0.5f - Replay_btn.height * 0.5f - Main_btn.height - 10f, Main_btn.width, Main_btn.height), Main_btn, guiRectStyle)) {
				Time.timeScale = 1;
                Application.LoadLevel ("Main");
			}
		}

		//结束时的按钮

		if (GS == GameState.End) {
            if(Application.loadedLevelName == "Level1")
            {
                if (GUI.Button (new Rect (screenX * 0.5f - Replay_btn.width * 0.5f, screenY * 0.5f + 10f, Replay_btn.width, Replay_btn.height), Replay_btn, guiRectStyle)) {
                Application.LoadLevel ("Level1");
                 }
			}

            else if (Application.loadedLevelName == "Level2")
            {
                if (GUI.Button(new Rect(screenX * 0.5f - Replay_btn.width * 0.5f, screenY * 0.5f + 10f, Replay_btn.width, Replay_btn.height), Replay_btn, guiRectStyle))
                {
                    Application.LoadLevel("Level2");
                }
            }

            else if (Application.loadedLevelName == "Level3")
            {
                if (GUI.Button(new Rect(screenX * 0.5f - Replay_btn.width * 0.5f, screenY * 0.5f + 10f, Replay_btn.width, Replay_btn.height), Replay_btn, guiRectStyle))
                {
                    Application.LoadLevel("Level3");
                }
            }

            if (GUI.Button (new Rect (screenX * 0.5f - Main_btn.width * 0.5f, screenY * 0.5f + Replay_btn.height + 20f, Main_btn.width, Main_btn.height), Main_btn, guiRectStyle)) {
                Application.LoadLevel ("Main");
			}
		}
	}
   
	public void GAMEOVER ()
	{
		GS = GameState.End;
		_fade.FadeOut ();
		result_window.gameObject.SetActive (true);
		result_Gold_Label.text = string.Format ("{0:N0}", GetMoney);
		result_Meter_Label.text = string.Format ("{0:N0}", Meter);
        
        //计算分数
        score = 18 * Meter + 18 * GetMoney;
        
        //连接数据库
        
        string constr = "Database=user;Data Source=sh-cdb-0sbjdp2b.sql.tencentcdb.com;User Id=root;Password=se2018-g18;pooling=false;port=63075"; //设置连接字符串
        MySqlConnection mycon = new MySqlConnection(constr);                  //实例化连接对象
        mycon.Open();

        if (Application.loadedLevelName == "Level1")
        {
            
            //向Rank1插入数据
            string s1 = "insert into Rank1(u_name1,u_score1) values ('" + name + "','" + score + "')";
            MySqlCommand mycom1 = new MySqlCommand(s1, mycon);          //初始化命令
            mycom1.ExecuteNonQuery();             //执行语句
            mycom1 = null;
            
        }
        else if (Application.loadedLevelName == "Level2")
        {

            //向Rank2插入数据
            string s2 = "insert into Rank2(u_name2,u_score2) values ('" + name + "','" + score + "')";
            MySqlCommand mycom2 = new MySqlCommand(s2, mycon);          //初始化命令
            mycom2.ExecuteNonQuery();             //执行语句
            mycom2 = null;
        }

        else if (Application.loadedLevelName == "Level3")
        {

            //向Rank3插入数据
            string s3 = "insert into Rank3(u_name3,u_score3) values ('" + name + "','" + score + "')";
            MySqlCommand mycom3 = new MySqlCommand(s3, mycon);          //初始化命令
            mycom3.ExecuteNonQuery();             //执行语句
            
            mycom3 = null;
            
        }
        mycon.Close();                       //关闭连接
        mycon.Dispose();                     //释放对象
    }
	
	public void GETCOIN ()
	{
		GetMoney += 1;
		Gold_Label.text = string.Format ("{0:N0}", GetMoney);
	}

	public void METERUPDATE ()
	{
		Meter += Time.deltaTime * GameSpeed;
		Meter_Label.text = string.Format ("{0:N0}<color=#ff3366> m</color>", Meter);

		//速度档位设置
        if(Application.loadedLevelName != "Level1")
        {
            if (Meter >= 50 && GameLv == 1) {
			GameLevelUp ();
		    }

		    if (Meter >= 100 && GameLv == 2) {
			GameLevelUp ();
		    }

		    if (Meter >= 150 && GameLv == 3) {
			GameLevelUp ();
		    }

		    if (Meter >= 200 && GameLv == 4) {
			GameLevelUp ();
		    }

		    if (Meter >= 250 && GameLv == 5) {
			    GameLevelUp ();
		    }

		    if (Meter >= 300 && GameLv == 6) {
			    GameLevelUp ();
		    }
        }
        else
        {

        }
		
	}

	public void GameLevelUp ()
	{
		GameLv += 1;
		GameSpeed += 3;
		_SM.ScrollSpeed += 0.1f;
		_BL.Speed = GameSpeed;
	}
}