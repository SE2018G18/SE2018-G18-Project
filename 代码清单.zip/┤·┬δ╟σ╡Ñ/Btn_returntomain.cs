﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;//注意这个不能少  
public class Btn_returntomain : MonoBehaviour
{
    // Use this for initialization  
    void Start()
    {

        GameObject btnObj = GameObject.Find("Btn_return");//"Button"为你的Button的名称  
        Button btn = btnObj.GetComponent<Button>();
        btn.onClick.AddListener(delegate ()
        {
            this.GoNextScene(btnObj);
        });
    }

    // Update is called once per frame  
    void Update()
    {
    }

    public void GoNextScene(GameObject NScene)
    {
        Application.LoadLevel("Main");//切换到主菜单场景 
    }
}