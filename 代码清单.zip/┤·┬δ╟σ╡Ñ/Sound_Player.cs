using UnityEngine;
using System.Collections;

public class Sound_Player : MonoBehaviour {

	//使用声音
	
	public AudioClip[] Sound;
	
	//0 : 跳跃
	//1 : 获得金币
	//2 : 死亡
	
	public void SoundPlay(int SoundNumber){
         
         GetComponent<AudioSource>().clip = Sound[SoundNumber];
         GetComponent<AudioSource>().Play();
		
    }
	
}
