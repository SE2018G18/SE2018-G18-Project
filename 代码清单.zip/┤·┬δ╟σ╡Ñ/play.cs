﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class play : MonoBehaviour {

    void playgame()
    {

        Application.LoadLevel("ChoseLevel");//跳转到选地图场景

    }
}
