﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections;


public class Btn_LoadScene : MonoBehaviour
{

    public string LoadSceneName;  //定义跳转场景的场景名字符串

    void OnMouseUp()                //鼠标点击时调用，触发按钮事件

    {
        Invoke("Jump", 0.5F);        //0.5秒调用“jump”方法

    }

    void Jump()

    {

        Application.LoadLevel(LoadSceneName);//跳转场景（场景名可在外部修改）

    }

}