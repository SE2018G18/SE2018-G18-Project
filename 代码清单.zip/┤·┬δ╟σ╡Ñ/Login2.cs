﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using UnityEngine;
using UnityEngine.UI;

public class Login2 : MonoBehaviour

{
    
    public static String uname;

    //勾选框
    public Toggle remPasswd;
    private Toggle fogPasswd;

    //注册信息
    public InputField inputName;
    public InputField inputPaswd;



    //跳转场景名称
    //public string LoadSceneName;//这个不需要这行代码


    //GUI 提示信息
    public Text ui_massage;
    private string stringmassage;


    void Update()
    {
        ui_massage.text = stringmassage;

    }
    
    public void OnCLick()
    {
        

        string name = inputName.text.Trim();

        string password = inputPaswd.text.Trim();

        string constr = "Database=user;Data Source=sh-cdb-0sbjdp2b.sql.tencentcdb.com;User Id=root;Password=se2018-g18;port=63075"; //设置连接字符串
        MySqlConnection mycon = new MySqlConnection(constr);
        mycon.Open();

        //用户名密码输入判断
        if (string.IsNullOrEmpty(name))
        {

            print(stringmassage = "提示信息：请输入昵称");
            return;
        }
        if (string.IsNullOrEmpty(password))
        {

            print(stringmassage = "提示信息：请输入密码");
            return;
        }

        MySqlCommand mycom = mycon.CreateCommand();
        string s1 = "select u_name,u_pass from user where u_name='" + name + "' and u_pass='" + password + "'";     //编写SQL命令
        mycom.CommandText = s1;                           //执行SQL命令
        MySqlDataAdapter md = new MySqlDataAdapter();
        md.SelectCommand = mycom;                       //让适配器执行SELECT命令
        DataSet myDS = new DataSet();                     //实例化结果数据集
        int n = md.Fill(myDS, "user");              //将结果放入数据适配器，返回元祖个数
        if (n != 0)
        {
            print(stringmassage = "提示信息：登录成功");            //登录成功
            //记录LOADING场景中需要读取的C场景名称
            Globe.loadName = "Main";
            //先进入B场景
            Application.LoadLevel("Loading");
        }

        else
        {
            print(stringmassage = "提示信息：用户名或密码错误");
            return;
        }
        
    
        string s3 = "select u_name from user where u_name = '" + name + "'and u_pass = '" + password + "'";
        mycom.CommandText = s3;
        MySqlDataReader re = mycom.ExecuteReader();
        if (re.Read())
        {
            
            uname = (String)re.GetValue(0);
        }
        mycon.Close();
        mycon.Dispose();                     //释放对象
    }
    
    
    void regist()
    {

        // print(stringmassage="提示信息：注册成功");
        Application.LoadLevel("Register");//跳转到注册场景

    }
}